public class Swap
{
	public static void main(String[] args) {
	    //case1
		int a=10;
		int b=5;
		int c;
		c=a;
		a=b;
		b=c;
		System.out.println(a);
		System.out.println(b);
		//case2
		int x=20;
		int y=30;
		int res=x+y;
		x=res-x;
		y=res-y;
		System.out.println(x);
		System.out.println(y);
	}
}
