public class Main
{
	public static void main(String[] args) {
		//largest of two numbers
		//case1
		int a=10,b=5;
		if(a>b)
		System.out.println("a is larger");
		else
		System.out.println("b is larger");
		//case2
		int c=20,d=14;
		int e;
		e=(c>d)?c:d;
		System.out.println(e);
		//smallest of three numbers
		int x=32,y=90,z=45;
		if(x<y&&x<z)
		System.out.println("x is smaller");
		else if(y<x&&y<z)
		System.out.println("y is smaller");
		else
		System.out.println("z is smaller");
		//print week numbers based on week names using switch case
		String name="monday";
		switch(name)
		{
		    case "sunday": System.out.println(1);break;
		    case "monday": System.out.println(2);break;
		    case "tuesday": System.out.println(3);break;
		    case "weednesday": System.out.println(4);break;
		    case "thursday": System.out.println(5);break;
		    case "friday": System.out.println(6);break;
		    case "saturday": System.out.println(7);break;
		    default:System.out.println("invalid name ");
		}
	}
}
