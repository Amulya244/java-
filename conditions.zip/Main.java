public class Main
{
	public static void main(String[] args) {
	    //if condition
		int person_age=25;
		if(person_age>=18)
		{
		    System.out.println("Elgible");
		}
		//if else condition
		int a=10,b=5;
		if(a<b) //if condition in if is true Stmt in if block is excuted if condion is false else block is excuted
		{
		    System.out.println(" b is greater");
		}
		else //at else we should not specify any condition
		{
		    System.out.println("a is greater");
		}
		// if else if
    	int x=5,y=10,z=15;
		if(x>y&&x>z) //only one if condition is possible to write
		{
		    System.out.println("x is greater than y and z");
		}
		else if(y>x&&y>z) //we can write as many else if conditions according to requirment
		{
		    System.out.println("y is greater than x and z");
		}
		else //there must be one else case
		{
		    System.out.println("z is greater than x and y");
		}
		//example
		if(true)//directly we are giving boolean value it will accept because after condition excution it will get a boolean value
		
		{
		    System.out.println(1);
		}
		else{
		    System.out.println(2);
		}
		if(false)
		{
		    System.out.println(3);
		}
		else{
		    System.out.println(4);
		}
		//nested if
		if(true)
		{
		    if(true)
		    {
		        System.out.println(7);
		    }
		    else{
		        System.out.println(9);
		    }
		}
		else{
		    System.out.println(6);
		}
		//example nested if
		//display week names based on week numbebr
		int date=2;
		if(date==1)
		System.out.println("Sunday");
		else if(date==2)
		System.out.println("monday");
		else if(date==3)
		System.out.println("tuesday");
		else if(date==4)
		System.out.println("weednesday");
		else if(date==5)
		System.out.println("thursday");
		else if(date==6)
		System.out.println("friday");
		else if(date==7)
		System.out.println("Saturday");
		else 
		System.out.println("Invalid date");
		//let us try above example with switch case
		int value=3;
		switch(value)
		{
		    case 1: System.out.println("Sunday");break;
		    case 2: System.out.println("monday");break;
		    case 3: System.out.println("tuesday");break;
		    case 4: System.out.println("weednesday");break;
		    case 5: System.out.println("thursday");break;
		    case 6: System.out.println("friday");break;
		    case 7: System.out.println("Saturday");break;
		    default: System.out.println("invalid value number");
		}
	}
}
